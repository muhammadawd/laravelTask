<?php

return [
    'name' => 'UserModule'
];
