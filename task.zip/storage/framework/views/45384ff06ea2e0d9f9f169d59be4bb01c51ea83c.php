<?php $__env->startSection('style'); ?>
    <?php echo e(Html::style('assetsUi/css/login.css')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-5 mx-auto">
                <div id="first">
                    <div class="myform form ">
                        <div class="logo mb-3">
                            <div class="col-md-12 text-center">
                                <h1>Login</h1>
                            </div>
                        </div>
                        <?php echo e(Form::open([
                        'method'=>'post',
                        'route'=>'handleLogin',
                        ])); ?>

                        <div class="form-group">
                            <label>Username </label>
                            <input class="form-control" name="username" type="text" placeholder="type username .."
                                   value="<?php echo e(old('username')); ?>">
                            <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="">Password</label>
                            <input class="form-control" name="password" type="password" placeholder="type password .."
                                   value="<?php echo e(old('username')); ?>">
                            <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                        </div>
                        <div class="form-group">
                            <p class="text-center">By signing up you accept our <a href="#">Terms Of Use</a></p>
                        </div>
                        <div class="col-md-12 text-center ">
                            <button type="submit" class=" btn btn-block mybtn btn-primary tx-tfm">Login</button>
                        </div>
                        <?php echo e(Form::close()); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminmodule::layouts.authMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\Modules/AdminModule\Resources/views/login.blade.php ENDPATH**/ ?>