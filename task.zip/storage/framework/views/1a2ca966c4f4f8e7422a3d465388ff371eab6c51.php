<div class="container-fluid">
    <?php echo e(Form::open([
        'method'=>'post',
        'route'=>'handleCreateUser',
    ])); ?>

    <div class="row">
        <div class="col-md-12">
            <fieldset>
                <legend><?php echo e(__('admin.add_user')); ?></legend>
                <div class="row">
                    <div class="col-md-4">
                        <label class="font-weight-bold"><?php echo e(__('admin.username')); ?></label>
                        <input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>"/>
                        <span class="text-danger"><?php echo e($errors->first('username') ?? ''); ?></span>
                    </div>
                    <div class="col-md-4">
                        <label class="font-weight-bold"><?php echo e(__('admin.mobile')); ?></label>
                        <input type="text" class="form-control" name="mobile" value="<?php echo e(old('mobile')); ?>"/>
                        <span class="text-danger"><?php echo e($errors->first('mobile') ?? ''); ?></span>
                    </div>
                    <div class="col-md-4">
                        <label class="font-weight-bold"><?php echo e(__('admin.password')); ?></label>
                        <input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>"/>
                        <span class="text-danger"><?php echo e($errors->first('password') ?? ''); ?></span>
                    </div>
                </div>
            </fieldset>
        </div>

        <div class="col-md-12 text-center mt-5 mb-5">
            <button class="btn btn-primary">
                <?php echo e(__('admin.add')); ?>

            </button>
        </div>
    </div>

    <?php echo e(Form::close()); ?>

</div><?php /**PATH C:\xampp\htdocs\blog\Modules/AdminModule\Resources/views/pages/users/add/templates/content.blade.php ENDPATH**/ ?>