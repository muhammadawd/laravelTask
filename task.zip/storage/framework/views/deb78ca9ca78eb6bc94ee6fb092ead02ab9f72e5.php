<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(asset('assetsUi/images/logo.png')); ?>" rel="icon">
    <?php echo $__env->make('adminmodule::includes.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('styles'); ?>
    <title><?php echo e($page_title ?? ''); ?></title>
    <script>
        window.back_menu = "<?php echo e(__('admin.back')); ?>";
    </script>
</head>
<body class="direction">
<div id="adg3-navigation"
     data-mobile-nav>

    <nav class="skeleton-nav position-fixed">

        <?php echo $__env->make('adminmodule::includes.sideslides', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

    <div class="drop-backup"></div>
</div>
<?php echo $__env->make('adminmodule::includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('adminmodule::includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\blog\Modules/AdminModule\Resources/views/layouts/adminMaster.blade.php ENDPATH**/ ?>