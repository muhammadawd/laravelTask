<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo e(Form::open([
            ''=>'',
        ])); ?>

        <div class="row">
            <div class="col-md-4">
                <label for="">username</label>
                <input type="text" value="<?php echo e($user->username); ?>" class="form-control" name="username">
            </div>
            <div class="col-md-4">
                <label for="">mobile</label>
                <input type="text" value="<?php echo e($user->mobile); ?>" class="form-control" name="mobile">
            </div>

            <div class="col-md-12 text-center mt-3">
                <button class="btn btn-danger">
                    edit
                </button>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminmodule::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\Modules/AdminModule\Resources/views/edit.blade.php ENDPATH**/ ?>