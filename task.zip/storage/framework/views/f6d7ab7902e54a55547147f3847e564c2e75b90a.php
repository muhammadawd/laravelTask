<!--Fonts css-->
<?php echo e(Html::style('assetsUi/css/flaticons.css')); ?>


<!-- core css-->
<?php echo e(Html::style('assetsUi/css/bootstrap.min.css')); ?>

<?php echo e(Html::style('assetsUi/css/bootstrap-grid.min.css')); ?>

<?php echo e(Html::style('assetsUi/css/bootstrap-reboot.min.css')); ?>

<?php if(app()->getLocale() == 'ar'): ?>
    <!--ar-->
    <?php echo e(Html::style('assetsUi/css/bootstrap-rtl.css')); ?>

    <!--ar-->
<?php endif; ?>
<?php echo e(Html::style('assetsUi/css/animate.css')); ?>

<?php echo e(Html::style('assetsUi/css/iziToast.min.css')); ?>

<?php echo e(Html::style('assetsUi/css/sweetalert2.min.css')); ?>

<?php echo e(Html::style('assetsUi/css/app.css')); ?>

<?php echo e(Html::style('assetsUi/css/slider-menu.jquery.css')); ?>

<?php echo e(Html::style('assetsUi/css/slider-menu.theme.jquery.css')); ?>

<?php if(app()->getLocale() == 'ar'): ?>
    <!--ar-->
    <?php echo e(Html::style('assetsUi/css/adg3-skeleton-nav-rtl.css')); ?>

    <!--ar-->
<?php else: ?>
    <?php echo e(Html::style('assetsUi/css/adg3-skeleton-nav.css')); ?>

<?php endif; ?>
<?php echo e(Html::style('assetsUi/css/bundle.css')); ?>

<?php if(app()->getLocale() == 'ar'): ?>
    <!--ar-->
    <?php echo e(Html::style('assetsUi/css/ar.css')); ?>

    <!--ar-->
<?php else: ?>
    <?php echo e(Html::style('assetsUi/css/main.css')); ?>

<?php endif; ?><?php /**PATH C:\xampp\htdocs\blog\Modules/AdminModule\Resources/views/includes/styles.blade.php ENDPATH**/ ?>