<?php if(session()->has('success')): ?>
    <script>
        iziToast.success({
            title: '<?php echo e(__('admin.success')); ?>',
            message: '<?php echo e(session()->get('success')); ?>',
            position: '<?php echo e(app()->getLocale() == 'ar' ? 'bottomLeft': 'bottomRight'); ?>',
        });
    </script>
<?php endif; ?>

<?php if(session()->has('info')): ?>
    <script>
        iziToast.info({
            title: '<?php echo e(__('admin.info')); ?>',
            message: '<?php echo e(session()->get('info')); ?>',
            position: '<?php echo e(app()->getLocale() == 'ar' ? 'bottomLeft': 'bottomRight'); ?>',
        });
    </script>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <script>
        iziToast.error({
            title: '<?php echo e(__('admin.error')); ?>',
            message: '<?php echo e(session()->get('error')); ?>',
            position: '<?php echo e(app()->getLocale() == 'ar' ? 'bottomLeft': 'bottomRight'); ?>',
        });
    </script>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\blog\Modules/AdminModule\Resources/views/includes/alerts.blade.php ENDPATH**/ ?>