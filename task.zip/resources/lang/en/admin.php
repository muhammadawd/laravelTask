<?php
/**
 * Created by PhpStorm.
 * User: Muhammad
 * Date: 4/10/2020
 * Time: 9:37 AM
 */
return [
    'welcome' => 'welcome',
    'users' => 'users',
    'username' => 'username',
    'password' => 'password',
    'is_verified' => 'is verified',
    'dashboard' => 'dashboard',
    'logout' => 'logout',
    'login' => 'login',
    'back' => 'back',
    'add_user' => 'add user',
    'all_users' => 'all users',
    'add' => 'add',
    'edit' => 'edit',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
];