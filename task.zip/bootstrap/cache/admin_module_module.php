<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AdminModule\\Providers\\AdminModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AdminModule\\Providers\\AdminModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);